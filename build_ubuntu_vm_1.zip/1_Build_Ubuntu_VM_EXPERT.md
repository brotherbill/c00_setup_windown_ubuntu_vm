c:/dev/ubuntu/1_Build_Ubuntu_VM_EXPERT.md

# Ubuntu VM Setup Guide (Expert)

## Prerequisites
- Windows 11, admin rights, ≥30GB free disk space

## Install Oracle VirtualBox
1. Visit: [https://www.virtualbox.org/](https://www.virtualbox.org/)
2. Click the **Get Started Download** button.
3. Click **Windows hosts** to download the latest installer.
4. Run the installer from your Downloads folder.
5. If prompted by User Access Control (UAC), click **Yes** to continue. (On corporate/school devices, contact tech support if blocked.)
6. Accept all default options. Approve network/USB driver prompts.

## If You See a "Microsoft Visual C++ 2019 Redistributable" Error
1. Dismiss the error and finish the installer dialogs.
2. Visit: [https://aka.ms/vs/16/release/vc_redist.x64.exe](https://aka.ms/vs/16/release/vc_redist.x64.exe) and install the package.
3. Restart your computer.
4. Re-run the VirtualBox installer.

---
For step-by-step details, see the BEGINNER guide.