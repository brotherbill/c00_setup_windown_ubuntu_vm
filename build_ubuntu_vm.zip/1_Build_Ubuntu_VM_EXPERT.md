# Ubuntu VM Setup Guide (Expert)

## Step 1: Prepare Windows 11 Host
- Log in as a standard user (admin rights will be requested as needed).
- Confirm at least 30GB free disk space is available.
- Ensure you have access to an admin password for elevation prompts.

## Step 2: Download and Install Oracle VirtualBox
1. Go to https://www.virtualbox.org/.
2. Click the Get Started "Download" button on the home page.
3. On the next page, click "Windows hosts".
4. This will download VirtualBox-7.2.6a-172322-Win.exe (or newer) to your Downloads folder.
5. Run the installer by double clicking it. Provide admin credentials when prompted.
6. Accept defaults. Approve network/USB driver prompts.

**If the installer completes without errors, you have completed the tasks in this document.**

**If you receive an error about the Microsoft Visual C++ 2019 Redistributable Package:**
1. Dismiss the error alert by clicking OK.
2. This brings up an Installer dialog.
3. Dismiss the "Oracle VirtualBox 7.2.6 Installer ended prematurely" dialog by clicking Finish.
4. An alert will appear: "Installation failed! Error: Fatal error during installation."
6. Click OK to dismiss the alert.
7. Restart your computer.
8. Download and install https://aka.ms/vs/16/release/vc_redist.x64.exe.
9. Reinstall Oracle VirtualBox
   
  **Error Handling:**
  - If you encounter any errors during reinstallation, resolving them is beyond the scope of this expert guide. Please seek additional help or consult official VirtualBox support resources.


---

For step-by-step, see the BEGINNER guide.