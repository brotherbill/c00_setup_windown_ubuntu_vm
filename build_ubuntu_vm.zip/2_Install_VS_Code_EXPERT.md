# 2. Install VS Code (Expert)

## Overview
Fast install for experienced users.

### Steps
- Download .deb from VS Code site.
- Install via terminal:
  ```sh
  sudo apt install ./code_*.deb
  ```
- Launch with `code`.
- Install C/C++ extension (ms-vscode.cpptools).

---
For detailed steps, see the BEGINNER guide.